#include<iostream>
using namespace std;

class Course {
	virtual void duration() = 0;
};
class OnlineCourse :public Course {
private:
	int weeks;
	int hoursperweek;
public:
	OnlineCourse(int w, int h) {
		weeks = w;
		hoursperweek = w;
	}
	void duration()override {
		cout << "Online Course Duration :"  << weeks << endl;
		cout << "Total Study Hours :" << weeks * hoursperweek << endl;
	}
};
class OflineCourse :public Course {
private:
	int months;
	int hoursperday;
public:
	OflineCourse(int m, int hpd) {
		months = m;
		hoursperday = hpd;
	}
	void duration()override {
		cout << "Ofline Course Duration :" << "months" << months << endl;
		cout << "Study Hours per Day:" << hoursperday  << endl;
	}
};
int main() {
	OnlineCourse online(8, 5);
	OflineCourse ofline(6, 4);

	cout << "Online Course Details :" << endl;
	online.duration();
	cout << "Ofline Course Details :" << endl;
	ofline.duration();

}
