#include <iostream>
using namespace std;

class Employee {
public:
    virtual double CalculateSalary() = 0;
};

class FullTimeEmployee : public Employee {
private:
    double fixedSalary;

public:
    FullTimeEmployee(double salary) {
        fixedSalary = salary;
    }

    double CalculateSalary() override {
        return fixedSalary;
    }
};

class PartTimeEmployee : public Employee {
private:
    int hoursWorked;
    double hourlyRate;

public:
    PartTimeEmployee(int hours, double rate) {
        hoursWorked = hours;
        hourlyRate = rate;
    }

    double CalculateSalary() override {
        return hoursWorked * hourlyRate;
    }
};

int main() {
    FullTimeEmployee f1(50000);
    PartTimeEmployee p1(80, 500);

    cout << "Full-Time Employee Salary: "
        << f1.CalculateSalary() << endl;

    cout << "Part-Time Employee Salary: "
        << p1.CalculateSalary() << endl;

    return 0;
}